/* global QUnit */

sap.ui.require(["sync6/exercise2107/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
