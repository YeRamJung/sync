sap.ui.define([
	"sync6/exercise21_07/test/unit/controller/View.controller"
], function () {
	"use strict";
});
